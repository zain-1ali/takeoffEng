# TakeOff Studio – Cursor AI build kit

This kit gives Cursor what it needs to build the production version of TakeOff Studio, a SaaS for quantity surveyors. It covers take-off, bar schedules, rate analysis, reports, collaboration and billing.

## What's inside

| Path | Purpose |
|---|---|
| `.cursor/rules/takeoff-studio.mdc` | Always-on project rules: stack, conventions, design tokens, money handling, testing |
| `docs/01_ENGINE_SPEC.md` | **The measurement and pricing engine**, module by module. It defines every formula, BOQ code, rate recipe and bill of materials rule. Frontend and backend both use it. |
| `docs/02_FRONTEND_PROMPT.md` | Paste into Cursor Agent to build `apps/web` (Next.js) |
| `docs/03_BACKEND_PROMPT.md` | Paste into Cursor Agent to build `apps/api` (NestJS) |
| `apps/api/prisma/schema.prisma` | Complete database schema, ready for `prisma migrate dev` |
| `reference/takeoff_studio_team.html` | The working prototype, which is the **source of truth** for behaviour, wording and numbers |

## How to use it in Cursor

1. **Set up the repo.** Create an empty repo and copy this whole kit into it. Open it in Cursor.
2. **Check the rules are loaded.** Confirm Cursor Settings → Rules shows `takeoff-studio.mdc` as *Always*.
3. **Build the engine first.** Open Agent and send:
   > Read `docs/01_ENGINE_SPEC.md` and `reference/takeoff_studio_team.html`. Build `packages/engine` exactly as specified, phase by phase, with the snapshot tests. Stop after each phase and show the test results.
4. **Build the backend.** In a new Agent chat, send `@docs/03_BACKEND_PROMPT.md @docs/01_ENGINE_SPEC.md @apps/api/prisma/schema.prisma`, then say **"Build phase 1"**. Continue phase by phase.
5. **Build the frontend.** In a new Agent chat, send `@docs/02_FRONTEND_PROMPT.md @docs/01_ENGINE_SPEC.md @reference/takeoff_studio_team.html`, then say **"Build phase 1"**. Continue phase by phase.
6. **When Cursor drifts,** reply: *"Compare with the prototype and the engine spec, list the differences, then fix them."*

## Build order

`packages/types` → `packages/engine` (tests green) → `apps/api` phases 1–3 → `apps/web` phases 1–6 → realtime (both) → billing (both) → exports → hardening.

## Features the prompts cover

- **Project types:** buildings (foundations only, single storey, multi-storey), roads, concrete bridges.
- **Take-off:** frame with bar-by-bar reinforcement; masonry; wall, floor and ceiling finishes; electrical; plumbing.
- **Roofing:** one step with a **method dropdown** – simple rectangles, or complex planes, lines, openings and a truss schedule.
- **Calculator inputs:** every numeric field accepts formulas such as `20*15+4*2.5`, `(6-0.3)*2` or `200*5%`, with a live result badge and **Enter** to replace the formula with its result.
- **Pricing:** rate analysis from a resource databank; any currency, number format and tax.
- **Reports:** cover page, charted summary, BOQ, BOM, rate analysis report, bar schedule, dimension sheet, dashboard.
- **Collaboration:** presence, comments, tasks, versions.
- **Business:** landing page, pricing plans, Stripe + mobile-money checkout.

## Before going live, replace

- **Resource databank prices.** The prototype prices are indicative starting points, not market rates.
- **Plan prices and payment keys.** Use your own Stripe, Flutterwave and Paystack accounts.
- **Brand name.** `TakeOff Studio` is a placeholder constant.
- **Legal pages.** Terms, privacy and the data processing agreement need legal review for each country you sell in.
